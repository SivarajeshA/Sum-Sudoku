import sumsudoku.PuzzleCreator
import sumsudoku.PuzzleCreatorV2

object Main
{
  def testEquivalence() = {
    val x = twiddlebits.BV_VAR("x")
    val num1 = twiddlebits.BV_NUM(1)
    val p = (x * num1)

    val num2 = twiddlebits.BV_NUM(2)
    val q = (x * num2)

    val r = twiddlebits.ExprChecker.areEquivalent(p, q)
   // assert(r._1)

    // Add more tests here.
    // Refer to this webpage for a whole bunch of interesting hacks
    // you can use for your tests:
    // https://graphics.stanford.edu/~seander/bithacks.html
  }

  def main(args: Array[String]) {
    testEquivalence()
    println("Question 1: Done")
   /* val puzzle = sumsudoku.Puzzle(
      3, 5, // n and m`
      List(9, 10, 12), // row sum
      List(9, 10, 12),  // col sum
      List( // empty grid
        List(0, 0, 0),
        List(0, 0, 0),
        List(0, 0, 0)))*/


    /*val puzzle = sumsudoku.Puzzle(7,10,List(34, 36, 40, 36, 39, 35, 35),List(34, 39, 38, 28, 37, 40, 39),List())
    val solved = sumsudoku.Solver.solve(puzzle)
    assert (solved.isValid())
    assert (solved.gridSize == puzzle.gridSize &&
      solved.maxValue == puzzle.maxValue &&
      solved.rowSums == puzzle.rowSums &&
      solved.colSums == puzzle.colSums)
    println("Question 2(a): Done")
   // println("\n"+PuzzleCreator.create(2,5,5))

   // println("\n"+PuzzleCreatorV2.create(3,5,4))

    println("Question 2(b)")*/
    val p1 = sumsudoku.PuzzleCreator.create(3, 10, 20)
    println(p1)

   /* println("Question 2(c)")
    val p2 = sumsudoku.PuzzleCreatorV2.create(3, 5, 1)
    assert (p1.size == 1)
    assert (p1.head.isValid)*/
  }
}
