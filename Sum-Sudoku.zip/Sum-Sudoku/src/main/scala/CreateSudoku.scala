package sumsudoku

import com.microsoft.z3
import com.microsoft.z3.{ArithExpr, BoolExpr}

import scala.collection.mutable.ListBuffer

object PuzzleCreator {
  /** You must create numPuzzles number of different puzzles
   *  and return them.
   *
   *  You must throw an IllegalArgumentException if it is not
   *  possible to create a puzzle for the provided parameters.
   */
  def create(gridSize : Int, maxValue : Int, numPuzzles : Int) : List[Puzzle] = {
    val ctx = new z3.Context()
    val S = ctx.mkSolver()
    val n = gridSize
    val max= maxValue
    var res = ListBuffer[Puzzle]()

    //Creating grid variables
    var va: Int =0
    var grid_val = Map[Int, ArithExpr]()
    while(va<n*n){
      grid_val += (va -> ctx.mkIntConst(s"g$va"))
      va +=1
    }
    //grid 1 to 9 constraint
    grid_val.foreach({
      case (k,v) => S.add(ctx.mkAnd(ctx.mkGe(v,ctx.mkInt(1)), ctx.mkLe(v, ctx.mkInt(max))))
    })

    //Creating row sum constraint
    var li = ListBuffer[ArithExpr]()
    va =0
    var i : Int = 0
    for (row <- Range(0, n)) {
      for (col <- Range(0, n)) {
        li += grid_val(va)
        va +=1
      }

      S.add(ctx.mkEq(ctx.mkAdd(li:_*),ctx.mkIntConst(s"r$row"))) // r : row
      S.add(ctx.mkDistinct(li:_*))
      i+=1
      li.clear()
    }
    //Creating col sum constraint
    i=0
    va =0
    for (row <- Range(0, n)) {
      for (col <- Range(0, n)) {
        li += grid_val(va)
        va +=n
      }
      S.add(ctx.mkEq(ctx.mkAdd(li:_*),ctx.mkIntConst(s"c$row"))) // c : col
      S.add(ctx.mkDistinct(li:_*))
      i += 1
      va = row+1
      li.clear()
    }

    var no_puz = 0
    while(no_puz<numPuzzles) {
      if (S.check().toString.equals("SATISFIABLE")) {
      }
      else
        throw new IllegalArgumentException


        val m = S.getModel()

        var row_col_eq_constr = ListBuffer[BoolExpr]()
        var grid__eq_constr = ListBuffer[BoolExpr]()

        //Creating col and row sum eq constraint
        va = 0
        while (va < n) {
          row_col_eq_constr += ctx.mkEq(ctx.mkIntConst(s"r$va"), ctx.mkInt(m.eval(ctx.mkIntConst(s"r$va"), true).toString.toInt))
          row_col_eq_constr += ctx.mkEq(ctx.mkIntConst(s"c$va"), ctx.mkInt(m.eval(ctx.mkIntConst(s"c$va"), true).toString.toInt))
          va += 1
        }
        //Creating grid eq constraint
        grid_val.foreach({
          case (k, v) => grid__eq_constr += ctx.mkEq(v, ctx.mkInt(m.eval(v, true).toString.toInt))
        })

        //Creating final single constraint
        val solv: BoolExpr = ctx.mkAnd(ctx.mkAnd(row_col_eq_constr: _*), ctx.mkNot(ctx.mkAnd(grid__eq_constr: _*)))


        if (S.check(solv).toString.equals("SATISFIABLE")) { // No Unique Soln
          S.add(ctx.mkNot(ctx.mkAnd(row_col_eq_constr: _*))) //Adding Blocking Clause
        }
        else { // Unique Soln
          S.add(ctx.mkNot(ctx.mkAnd(row_col_eq_constr: _*))) //Adding Blocking Clause
          no_puz += 1
          //Collecting grid result
          var gridRes = ListBuffer[List[Int]]()
          var gridRest = ListBuffer[Int]()
          va = 0
          for (row <- Range(0, n)) {
            for (col <- Range(0, n)) {
              gridRest += m.eval(ctx.mkIntConst(s"g$va"), true).toString.toInt
              va += 1
            }
            gridRes += gridRest.toList
            gridRest.clear()
          }
          //      println("\ngrid res")
          //      print(gridRes)

          //Collecting row sum result
          var row_res = ListBuffer[Int]()
          va = 0
          while (va < n) {
            row_res += m.eval(ctx.mkIntConst(s"r$va"), true).toString.toInt
            va += 1
          }
          //      println("\nRow sum")
          //      print(row_res)

          //Collecting col sum result
          var col_res = ListBuffer[Int]()
          va = 0
          while (va < n) {
            col_res += m.eval(ctx.mkIntConst(s"c$va"), true).toString.toInt
            va += 1
          }
          //      println("\nCol sum")
          //      print(col_res)

          res += Puzzle(gridSize, maxValue, row_res.toList, col_res.toList, gridRes.toList)

        }
      }
      res.toList
    }
}
