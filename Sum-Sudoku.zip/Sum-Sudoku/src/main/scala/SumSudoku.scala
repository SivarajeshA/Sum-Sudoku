package sumsudoku

import com.microsoft.z3
import com.microsoft.z3.{ArithExpr, BitVecExpr}

import scala.collection.mutable.ListBuffer

/** In the notation (n,m) sum-sudoku puzzle:
 * - n is the gridSize variable,
 * - m is the maxValue variable,
 * - the row and column sums are in the respective variables.
 * - If an entry in the grid is zero, it means that cell is not
 *   filled (or unknown) and the solver will need to find a
 *   value of this grid entry.
 */
case class Puzzle(gridSize: Int, maxValue: Int,
                  rowSums: List[Int],
                  colSums: List[Int],
                  grid: List[List[Int]])
{
  def isValid() : Boolean = {
    for (row <- Range(0, gridSize)) {
      val rowValues = grid(row)
      val rowSum = rowValues.sum
      assert (rowValues.distinct.size == gridSize)
      assert (rowValues.forall(v => 1 <= v && v <= maxValue))
      if (rowSum != rowSums(row)) return false
    }
    for (col <- Range(0, gridSize)) {
      val colValues = grid.foldRight(List.empty[Int])((row, c) => row(col) :: c)
      val colSum = colValues.sum
      assert (colValues.distinct.size == gridSize)
      assert (colValues.forall(v => 1 <= v && v <= maxValue))
      if (colSum != colSums(col)) return false
    }
    return true
  }
}

/**
 *  Implement your solver here.
 *  You must use SMT and Z3.
 */
object Solver
{
  /** This must solve the puzzle and return a new Puzzle where all the
   *  0-valued entries in the grid have been replaced by an appropriate
   *  solution.
   *
   *  You must throw an IllegalArgumentException if the puzzle has no
   *  solution.
   */

  def solve(puzzle : Puzzle) : Puzzle = {
    /* Hard-coding a solution just for testing. */

    val ctx = new z3.Context()
    val S = ctx.mkSolver()

    //To find minimum no. of bits required for BitVector arithmetic here
    def bits_Count(li : List[Int]) : Int ={

      //To find max value in row and col sum
      var max = 0
      for(x <- li){
        if(max < x){
          max = x
        }
      }
      //println(ma)
      //To find no. of bits required to represent max value
      var bits = 0
      while (max > 0) {
        max = max / 2
        bits += 1
      }
      bits
    }

    //To add ListBuffer of BitVecExpr
    def mkBVADD(li : ListBuffer[BitVecExpr] ): BitVecExpr ={
      var a = li(0)
      for (x <- li.drop(1)){
        a = ctx.mkBVAdd( a, x)
      }
      a
    }

    val n = puzzle.gridSize
    val max= puzzle.maxValue
    val rowsum = puzzle.rowSums
    val colsum = puzzle.colSums
    val no_bits = bits_Count(rowsum ++ colsum)

    var va: Int =0
    var vars = Map[Int, BitVecExpr]()
    while(va<n*n){
      vars += (va ->  ctx.mkBVConst(s"v$va", no_bits))
      va +=1
    }
    vars.foreach({
      case (k,v) => S.add(ctx.mkAnd(ctx.mkBVUGE(v,ctx.mkBV(1,no_bits)), ctx.mkBVULE(v, ctx.mkBV(max,no_bits))))
    })
    var li = ListBuffer[BitVecExpr]()
    va =0
    var i : Int = 0
    for (row <- Range(0, n)) {
      for (col <- Range(0, n)) {
        li += vars(va)
        va +=1
      }
      S.add(ctx.mkEq(mkBVADD(li),ctx.mkBV(rowsum(i),no_bits)))
      S.add(ctx.mkDistinct(li:_*))
      i+=1
      li.clear()
    }
    i=0
    va =0
    for (row <- Range(0, n)) {
      for (col <- Range(0, n)) {
        li += vars(va)
        va +=n
      }
      S.add(ctx.mkEq(mkBVADD(li),ctx.mkBV(colsum(i),no_bits)))
      S.add(ctx.mkDistinct(li:_*))
      i+=1
      va = row+1
      li.clear()
    }
    if(S.check().toString.equals("SATISFIABLE")) {
      val m = S.getModel()
      /*  va = 0
       while(va<n*n){
      println(m.eval(ctx.mkBVConst((s"v$va"),no_bits), true))
      va +=1
    }*/
      var gridRes = ListBuffer[List[Int]]()
      var gridRest = ListBuffer[Int]()
      va = 0
      for (row <- Range(0, n)) {
        for (col <- Range(0, n)) {
          gridRest += m.eval(ctx.mkBVConst((s"v$va"),no_bits), true).toString.toInt
          va += 1
        }
        gridRes += gridRest.toList
        gridRest.clear()
      }
      val res = Puzzle(n, max, rowsum, colsum, gridRes.toList)
      //println(res)
      res
    }
    else
      throw new IllegalArgumentException
  }
}
